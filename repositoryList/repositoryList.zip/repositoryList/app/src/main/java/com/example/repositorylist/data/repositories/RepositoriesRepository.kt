package com.example.repositorylist.data.repositories

import com.example.repositorylist.api.GithubApi
import com.example.repositorylist.data.model.github.RepositoryListResponse
import io.reactivex.Single

class RepositoriesRepository(private val githubApi: GithubApi) {

    fun listRepository(page: Int = 1): Single<RepositoryListResponse> {
        return githubApi.getRepositoryList(QUERY, STARS, page)
    }

    companion object {
        const val QUERY = "language:kotlin"
        const val STARS = "stars"
    }
}